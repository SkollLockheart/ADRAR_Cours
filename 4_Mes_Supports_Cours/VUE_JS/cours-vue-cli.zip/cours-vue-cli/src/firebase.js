import firebase from 'firebase/app';
import "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyAnH4_O_G9_q9oNnSqD2_9rJFuvhqVTkDA",
  authDomain: "test-fb-7fad8.firebaseapp.com",
  databaseURL: "https://test-fb-7fad8-default-rtdb.firebaseio.com",
  projectId: "test-fb-7fad8",
  storageBucket: "test-fb-7fad8.appspot.com",
  messagingSenderId: "706519601682",
  appId: "1:706519601682:web:0f6642142c90a508d77ecb"
};

  // Initialize Firebase
firebase.initializeApp(firebaseConfig);
export default firebase.database()